package com.example.WatchlistAppServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class WatchlistServer {

	public static void main(String[] args) {
		SpringApplication.run(WatchlistServer.class, args);
	}

}
