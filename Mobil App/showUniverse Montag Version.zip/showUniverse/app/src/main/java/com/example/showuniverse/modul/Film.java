package com.example.showuniverse.modul;


public class Film extends Medium {
    public Film() {
    }

    public Film(int erscheinungsjahr, String beschreibung, String titel, String embeddedcode, double dauer, String imageUrl, double bewertung) {
        super(erscheinungsjahr, beschreibung, titel, embeddedcode, dauer, imageUrl, bewertung);
    }


}

