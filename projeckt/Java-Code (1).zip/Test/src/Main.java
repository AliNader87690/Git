/**@author Moamen Alkatib 7206217
 * @author Ali Nader 7208457
 */
public class Main {
	/**
	 * Main 
	 * @param args : 
	 */
	public static void main(String[] args) {
		//System.out.println(	Gasverwaltung.tupelEinfuegen("Firma", "5,'Moamen','Menden','01791723646','moamen@gmail.com'"));
		//System.out.println( Gasverwaltung.tupelAendern("Firma","firmaname='Moamen'", "firmaid>0"));
		//System.out.println(Gasverwaltung.tupelLoeschen("firma", "firmaid=5"));
		//Gasverwaltung.showTabelle();
		Gasverwaltung.unterTarif();
	}

}
